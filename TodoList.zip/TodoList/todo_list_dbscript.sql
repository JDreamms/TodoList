-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.21-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for todo_list
CREATE DATABASE IF NOT EXISTS `todo_list` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `todo_list`;

-- Dumping structure for table todo_list.task
CREATE TABLE IF NOT EXISTS `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table todo_list.task: ~0 rows (approximately)
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
/*!40000 ALTER TABLE `task` ENABLE KEYS */;

-- Dumping structure for table todo_list.task_details
CREATE TABLE IF NOT EXISTS `task_details` (
  `id` int(11) NOT NULL,
  `details` text,
  PRIMARY KEY (`id`),
  CONSTRAINT `task_taskdetails_fk` FOREIGN KEY (`id`) REFERENCES `task` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table todo_list.task_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `task_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_details` ENABLE KEYS */;

-- Dumping structure for table todo_list.task_status
CREATE TABLE IF NOT EXISTS `task_status` (
  `id` int(11) NOT NULL,
  `status_id` int(11) DEFAULT NULL,
  `datetimevalue` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `taskstatuses_taskstatus_fk` (`status_id`),
  CONSTRAINT `task_taskstatus_fk` FOREIGN KEY (`id`) REFERENCES `task` (`id`),
  CONSTRAINT `taskstatuses_taskstatus_fk` FOREIGN KEY (`status_id`) REFERENCES `task_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table todo_list.task_status: ~0 rows (approximately)
/*!40000 ALTER TABLE `task_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_status` ENABLE KEYS */;

-- Dumping structure for table todo_list.task_statuses
CREATE TABLE IF NOT EXISTS `task_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table todo_list.task_statuses: ~4 rows (approximately)
/*!40000 ALTER TABLE `task_statuses` DISABLE KEYS */;
INSERT INTO `task_statuses` (`id`, `description`) VALUES
	(1, 'Open'),
	(2, 'In progress'),
	(3, 'Completed'),
	(4, 'Canceled');
/*!40000 ALTER TABLE `task_statuses` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
