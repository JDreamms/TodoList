<?php

class DataRetrieval
{
    private static $hostname = "";
    private static $user = "root";
    private static $password = "";
    private static $database = "todo_list";
    
    static public function connection()
    {
        $mysqli = new mysqli(self::$hostname, self::$user, self::$password, self::$database);
        if ($mysqli->connect_errno) {
            echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
        }
        return $mysqli;
    }
    
    static private function get_result($query, $conn = false)
    {
        if (! $conn) {
            return self::connection()->query($query);
        } else {
            return $conn->query($query);
        }
    }
    
    static private function get_field_names($query)
    {
        $fnames = []; //field names
        $result = self::get_result($query);//to avoid opening a connection twice
        if ($result) {
            foreach ($result->fetch_fields() AS $field) {
                $fnames[] = $field->name;
            }
        }
        return $fnames;
    }
    
    static public function get_multiple_rows($query)
    {
        $result = self::get_result($query);
        $field_names = self::get_field_names($query);
        $rows = [];
        $i = 0;
        if ($result) {
            while ($row = $result->fetch_assoc() ) {
                foreach ($field_names AS $fname) {
                    $rows[$i][$fname] = $row[$fname];
                }
                $i++;
            }
        }
        return $rows;
    }
    
    static public function get_last_id($conn = false)
    {
        $result = self::get_result("SELECT LAST_INSERT_ID() as last_id", $conn);
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['last_id'];
        } else {
            false;
        }
    }
    
}