<?php

class GlobalVars
{
    
    static public function post($field_name)
    {
        if (array_key_exists($field_name, $_POST)) {
            return $_POST[$field_name];
        } else {
            return false;
        }
    }
}