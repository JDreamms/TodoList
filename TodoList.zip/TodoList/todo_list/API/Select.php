<?php

require_once 'DataRetrieval.php';

class Select
{
    static public function getHTML($query, $name, $id)
    {
        $query = "select id, description from task_statuses";
        $rows = DataRetrieval::get_multiple_rows($query);
        echo("<select name=$name id=$id>");
        foreach($rows AS $row) {
            echo("<option value={$row['id']}>{$row['description']}</option>");
        }
        echo("</select>");
    }
}