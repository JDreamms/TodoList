<?php

class DataStorage
{
    private static $hostname = "";
    private static $user = "root";
    private static $password = "";
    private static $database = "todo_list";
    
    static public function connection()
    {
        $mysqli = new mysqli(self::$hostname, self::$user, self::$password, self::$database);
        if ($mysqli->connect_errno) {
            echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
        }
        return $mysqli;
    }
    
    static public function store($query, $conn = false)
    {
        if (! $conn) {
            $conn = self::connection();
        }
        $conn->query($query);
    }
}