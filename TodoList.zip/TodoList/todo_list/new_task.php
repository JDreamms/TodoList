<?php

    require_once 'API/Select.php';
    require_once 'API/GlobalVars.php';
    require_once 'API/DataStorage.php';
    require_once 'API/DataRetrieval.php';
    
    $description_missing = false;
    if (GlobalVars::post('submit')) {
        if(strlen(GlobalVars::post('description')) == 0) {
            $description_missing = true;
        } else {
            $conn = DataStorage::connection();
            DataStorage::store("INSERT INTO `task` (`description`) VALUES ('".GlobalVars::post('description')."')", $conn);
            $task_id = DataRetrieval::get_last_id($conn);
            DataStorage::store("INSERT INTO `task_status` (`id`, `status_id`) VALUES($task_id, ".GlobalVars::post('status').")", $conn);
        }
    }
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php if ($description_missing) echo("<p style='color:red;'>The description is required for creating a task.</p>");?>
        <form action="new_task.php" method="post">
          Description: <input type="textarea" name="description"><br>
          Status: <?php Select::getHTML("SELECT * FROM task_statuses", "status", "status") ?>
          <input type="submit" name="submit" value="Submit">
        </form>
    </body>
</html>