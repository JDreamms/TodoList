<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php

    require_once 'API/DataRetrieval.php';

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href="new_task.php">Create New Task</a>
        <?php
//        $query = "select id, description from task_statuses";
//        $rows = DataRetrieval::get_multiple_rows($query);
//        
//        foreach($rows AS $row) {
//            echo($row['id']." - ".$row['description']);
//            echo("</br>");
//        }
        ?>
    </body>
</html>
